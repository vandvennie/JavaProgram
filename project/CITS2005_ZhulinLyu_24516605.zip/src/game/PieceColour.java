package game;

public enum PieceColour {
    NONE, WHITE, BLACK
}
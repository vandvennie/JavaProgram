public abstract class Expression {
    public abstract void describe();

    public abstract int evaluate();
}
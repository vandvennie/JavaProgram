public class CodingBat {
    public boolean cigarParty(int cigars, boolean isWeekend) {
        if (isWeekend) return cigars >= 40;
        else return cigars >= 40 && cigars <= 60;
    }

    public int caughtSpeeding(int speed, boolean isBirthday) {
        int extra = 0;
        if (isBirthday) extra = 5;
        if (speed >= 61+extra && speed <= 81+extra) return 1;
        if (speed >= 81+extra) return 2;
        return 0;
    }

    public boolean twoAsOne(int a, int b, int c) {
        return a+b==c || a+c==b || c+b==a;
    }
}
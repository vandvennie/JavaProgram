public class Operators {
    public static void main(String[] args) {
        boolean a = true, b = false;
        System.out.println(a && b);
        System.out.println(!(a && b));
        System.out.println(a || b);
        System.out.println(a == b);
        System.out.println(a != b);
        System.out.println(a ^ b);
    }
}
import java.util.Scanner;

public class FourToEight {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        if (num >= 4 && num <= 8) {
            System.out.println("yes");
        } else {
            System.out.println("no");
        }
    }
}
public class Addition {
    public static void main(String[] args) {
        int a = 1;
        double b = 1.0;
        System.out.println(a + b);
    }
}
public class Nums {
    public static void main(String[] args) {
        int[] nums = new int[4];
        nums[0] = 3;
        nums[1] = 1;
        nums[2] = 4;
        nums[3] = 1;
        for (int num : nums) // For each element in nums
            System.out.println(num);
    }
}
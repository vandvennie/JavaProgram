public class CompoundAssignment {
    public static void main(String[] args) {
        int x = 1;
        x += 4;
        x -= 3;
        x *= 2;
        x /= 3;
        System.out.println("x=" + x);
    }
}

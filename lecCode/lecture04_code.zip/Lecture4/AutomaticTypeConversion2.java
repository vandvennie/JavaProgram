public class AutomaticTypeConversion2 {
    public static void main(String[] args) {
        double d = 2.3;
        // Not allowed!
        // int num = d;
        int x = 10;
        long y = x;
        // Not allowed!
        // short z = x;
    }
}

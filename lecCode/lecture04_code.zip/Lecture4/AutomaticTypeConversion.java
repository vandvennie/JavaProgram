public class AutomaticTypeConversion {
    public static void main(String[] args) {
        int num = 10;
        double d = num;
        System.out.println("num=" + num);
    }
}

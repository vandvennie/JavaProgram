public class VariableInit {
    public static void main(String[] args) {
        double a = 4.5, b, c = 1.0;
        b = a+c;
        double d = a*b*c*2.0;
        System.out.println("d=" + d);
    }
}

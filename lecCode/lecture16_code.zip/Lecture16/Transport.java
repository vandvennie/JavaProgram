enum Transport {
    BUS, TRAIN, FERRY, TRAM
}
public class GenericPair<T, V> {
    public T first;
    public V second;

    public GenericPair(T first, V second) {
        this.first = first;
        this.second = second;
    }
}
public class StackFull extends Exception {
    public StackFull(String message) {
        super(message);
    }
}
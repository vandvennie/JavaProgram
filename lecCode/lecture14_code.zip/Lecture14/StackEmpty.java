public class StackEmpty extends Exception {
    public StackEmpty() {
        super("Stack is empty");
    }
}
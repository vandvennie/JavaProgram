public class HelloCITS {
    public static void main(String[] args) {
        System.out.println("Hello, CITS2005!");
    }
}
public class StaticX {
    public static String x;
}
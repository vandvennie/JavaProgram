public class If {
    public static void main(String[] args) {
        double x = 2.3;
        if (x < 4/2.0) {
            System.out.println("Not executed");
        }
        if (x < 5/2.0) {
            System.out.println("Executed");
        }
    }
}
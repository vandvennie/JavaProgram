public class Booleans {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;
        if (a)
            System.out.println("a");
        if (b)
            System.out.println("b");
    }
}
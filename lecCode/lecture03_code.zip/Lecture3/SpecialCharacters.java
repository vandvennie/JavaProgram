public class SpecialCharacters {
    public static void main(String[] args) {
        char tab = '\t';
        // Concatenation of a char
        System.out.println("Hello" + tab + "World");
        String s = "backslash: \\, double quote: \", single quote: \'";
        System.out.println(s+"\n"+"another line!");
    }
}
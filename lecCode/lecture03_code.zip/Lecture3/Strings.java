public class Strings {
    public static void main(String[] args) {
        String hello = "Hello";
        String world = "World";
        System.out.println(hello + " " + world);
    }
}
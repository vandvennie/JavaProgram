public class Chars {
    public static void main(String[] args) {
        char a = 'a'+1;
        char b = 'b';
        System.out.println(a);
        System.out.println(b);
    }
}
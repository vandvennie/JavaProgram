// public class MazeSolver {
//     public void setPositionBlocked(int row, int col) {
//         // Not real code
//     }
//     public Path findPath(int sr, int sc, int dr, int dc) {
//         // Not real code
//         return null;
//     }
// }

class Path {}

// SRP adhering version
class Grid {
    public void setPositionBlocked(int row, int col) {
        // Not real code
    }
    public boolean getPositionBlocked(int row, int col) {
        // Not real code
        return false;
    }
}

public class MazeSolver {
    public void setMaze(Grid m) {
        // Not real code
    }
    public Path findPath(int sr, int sc, int dr, int dc) {
        // Not real code
        return null;
    }
}
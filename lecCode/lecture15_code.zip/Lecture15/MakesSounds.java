public interface MakesSounds {
    String sound();
}
public interface StringStack {
    String pop();
    void push(String s);
    boolean isEmpty();
}
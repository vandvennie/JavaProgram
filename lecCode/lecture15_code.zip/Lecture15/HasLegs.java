public interface HasLegs {
    int countLegs();
}
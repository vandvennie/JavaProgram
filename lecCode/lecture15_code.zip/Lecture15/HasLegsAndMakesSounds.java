public interface HasLegsAndMakesSounds extends HasLegs, MakesSounds {
    // This interface has no methods of its own.
    // It inherits the methods from its two parent interfaces.
}
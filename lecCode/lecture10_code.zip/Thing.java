public class Thing {
    public int x;
    protected float y;
    private String z;
}
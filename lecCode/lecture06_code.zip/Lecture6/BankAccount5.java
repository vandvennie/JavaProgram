class BankAccount5 {
    String ownerName;
    int balance;
    BankAccount5() {
        ownerName = null;
        balance = 0;
    }
}
class BankAccount2 {
    String ownerName;
    int balance;

    void depositMoney(int amount) {
        balance += amount;
    }
}
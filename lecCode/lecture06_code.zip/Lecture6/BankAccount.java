class BankAccount {
    String ownerName;
    int balance;
}
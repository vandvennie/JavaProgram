class BankAccount6 {
    String ownerName;
    int balance;
    
    BankAccount6(String ownerName, int balance) {
        this.ownerName = ownerName;
        this.balance = balance;
    }

    BankAccount6(String ownerName) {
        this.ownerName = ownerName;
        this.balance = 0;
    }
}